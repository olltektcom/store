<section class="news-update">
    <div class="news-update-grid">
        <div class="block1">
            <img src="vendor/webkul/shop/assets/images/1.png" alt="" />
        </div>
        <div class="block2">
            <div class="sub-block1">
                <img src="vendor/webkul/shop/assets/images/2.png" alt="" />
            </div>
            <div class="sub-block2">
                <img src="vendor/webkul/shop/assets/images/3.png" alt="" />
            </div>
        </div>
    </div>
</section>

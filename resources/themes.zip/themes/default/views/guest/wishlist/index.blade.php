<script>
    window.location.href = window.location.href.replace('/guest-wishlist', '');
</script>
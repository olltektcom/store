<a href="{{ route('shop.home.index') }}">
    <img
        src="{{ asset('themes/velocity/assets/images/static/logo-text-white.png') }}"
        class="logo full-img" alt="" width="200" height="50" />
</a>
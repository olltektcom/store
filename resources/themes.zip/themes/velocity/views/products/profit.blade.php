
<div class="product-profit">
    Profit {!! $product->getTypeInstance()->getProfitHtml() !!}
</div>
